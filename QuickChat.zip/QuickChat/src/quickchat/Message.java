/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quickchat;

import java.util.Random;

/**
 *
 * @author lab_services_student
 */
public class Message {
    private static int messageCount = 0;
    private final String messageID;
    private final String recipient;
    private final String message;
    private final String hash;

    public Message(String recipient, String message) {
        this.messageID = String.valueOf(new Random().nextInt(900000000) + 100000000);
        this.recipient = recipient;
        this.message = message;
        this.hash = createMessageHash();
        messageCount++;
    }

    public static int getMessageCount() {
        return messageCount;
    }

    public boolean checkRecipientCell() {
        return recipient.matches("^\\+\\d{10,13}$");
    }

    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    public String createMessageHash() {
        String[] words = message.split(" ");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : "";
        return messageID.substring(0, 2) + ":" + messageCount + ":" + first + last.toUpperCase();
    }

    public String printMessage() {
        return "Message ID: " + messageID +
                "\nMessage Hash: " + hash +
                "\nRecipient: " + recipient +
                "\nMessage: " + message;
    }

    public String sendMessage() {
        if (message.length() > 250) {
            int over = message.length() - 250;
            return "Message exceeds 250 characters by " + over + ", please reduce size.";
        }
        return "Message ready to send.";
    }

    public String getMessageID() {
        return messageID;
    }

    public String getHash() {
        return hash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }
}