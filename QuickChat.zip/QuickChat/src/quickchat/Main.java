/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quickchat;

import javax.swing.*;

/**
 *
 * @author lab_services_student
 */
public class Main {
    public static void main(String[] args) {
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String cell = JOptionPane.showInputDialog("Enter SA Cellphone (+27...):");
        String firstName = JOptionPane.showInputDialog("Enter your First Name:");
        String lastName = JOptionPane.showInputDialog("Enter your Last Name:");

        Login user = new Login(username, password, cell);
        String result = user.registerUser();
        JOptionPane.showMessageDialog(null, result);
        if (!result.equals("Registration successful!")) return;

        // Login
        String loginU = JOptionPane.showInputDialog("Login - Enter username:");
        String loginP = JOptionPane.showInputDialog("Login - Enter password:");
        boolean isLoggedIn = user.loginUser(loginU, loginP);
        JOptionPane.showMessageDialog(null, user.returnLoginStatus(firstName, lastName, isLoggedIn));
        if (!isLoggedIn) return;

        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
        MessageStore store = new MessageStore();

        int numMsgs = Integer.parseInt(JOptionPane.showInputDialog("How many messages to send?"));

        for (int i = 0; i < numMsgs; i++) {
            String rec = JOptionPane.showInputDialog("Enter recipient number:");
            String msg = JOptionPane.showInputDialog("Enter message (max 250 chars):");

            Message m = new Message(rec, msg);
            String status = m.sendMessage();
            if (!status.equals("Message ready to send.")) {
                JOptionPane.showMessageDialog(null, status);
                i--; continue;
            }

            int choice = JOptionPane.showConfirmDialog(null, "Send this message?\n" + m.printMessage(), "Send?", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
                store.addMessage(m);
                JOptionPane.showMessageDialog(null, "Message successfully sent.");
            } else {
                JOptionPane.showMessageDialog(null, "Message disregarded.");
            }
        }

        JOptionPane.showMessageDialog(null, "Total messages sent: " + store.getTotalMessages());
    }
}