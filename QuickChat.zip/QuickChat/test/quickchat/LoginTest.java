/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package quickchat;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class LoginTest {
    @Test
    public void testCheckUserNameSuccess() {
        Login login = new Login("abc_1", "Passw0rd!", "+27834567890");
        assertTrue(login.checkUserName());
    }

    @Test
    public void testCheckUserNameFail() {
        Login login = new Login("username", "Passw0rd!", "+27834567890");
        assertFalse(login.checkUserName());
    }

    @Test
    public void testPasswordComplexitySuccess() {
        Login login = new Login("abc_1", "Test1234@", "+27834567890");
        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testPasswordComplexityFail() {
        Login login = new Login("abc_1", "password", "+27834567890");
        assertFalse(login.checkPasswordComplexity());
    }

    @Test
    public void testCheckCellPhoneNumber() {
        Login login = new Login("abc_1", "Passw0rd!", "+27834567890");
        assertTrue(login.checkCellPhoneNumber());
    }
}
